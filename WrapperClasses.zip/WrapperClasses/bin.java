import java.util.Scanner;

public class bin {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int x = sc.nextInt();
		
		System.out.println(String.format("%08d", Integer.parseInt(Integer.toBinaryString(x))));
	}
	
}