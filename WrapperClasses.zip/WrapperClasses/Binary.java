
public class Binary {

	public static void main(String[] args) {
		
		int x = 20;
		System.out.println("java Test " +x);
		System.out.println("Given Number :"+x);
		
		System.out.println(String.format("Binary equivalent :%d", Integer.parseInt(Integer.toBinaryString(x))));
		System.out.println(String.format("Octal equivalent :%d", Integer.parseInt(Integer.toOctalString(x))));
		System.out.println(String.format("Hexadecimal equivalent :%d", Integer.parseInt(Integer.toHexString(x))));
	}
	
}