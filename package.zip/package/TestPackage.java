
import testPackage.Foundation;

public class TestPackage {
	public static void main(String[] args) {

		Foundation f = new Foundation();

			// visible cause its public
		System.out.println(f.var3);

		
	}
}