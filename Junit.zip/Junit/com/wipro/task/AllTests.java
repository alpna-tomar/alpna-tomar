package com.wipro.task;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({
	TestSort.class,
	TestStringConcat.class,
	TestCheckPresence.class
	
})
public class AllTests {

}
