package com.wipro.task;




import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class TestCheckPresence {

	@Test
	public void test() {
		DailyTasks d = new DailyTasks();
		String output = d.doStringConcat("abc", "null");
		
		//assertArrayEquals(new int[] { 1, 2, 3 }, d.sortValues(new int[] { 3, 2, 1 }));

		assertTrue(d.checkPresence("abcdeeee", "ab"));
		assertFalse(d.checkPresence("abcdeeee", "b"));
	}

}
