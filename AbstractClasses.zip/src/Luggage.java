
public class Luggage extends Compartment {

	@Override
	public String notice() {
		// TODO Auto-generated method stub
		return new String("Luggage");
	}

}