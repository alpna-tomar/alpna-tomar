import java.util.Scanner;
class lastDigit{
public static void main(String arg[])
{
int a,b;  
Scanner sc = new Scanner(System.in);  
a = sc.nextInt();  
b = sc.nextInt();
if((a % 10)==(b % 10)) 
{  
System.out.println("true");  
}  
else
{  
System.out.println("false");  
}
}}

  