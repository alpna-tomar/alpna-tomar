class ArgsCheck {
   public static void main(String[] args) {
		if (args.length == 0) {
			System.out.println("No values");
			return;
		}
                int j=args.length-1;
		for (int i =0;i< args.length;i++) 
                {
			System.out.print(args[i]);
                        if(j>0)
                           {System.out.print(",");
                            j--;}
		}
	}
}