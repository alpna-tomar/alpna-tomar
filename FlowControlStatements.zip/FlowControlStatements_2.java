import java.util.Scanner;
class evenodd{
public static void main(String arg[])
{
int a;  
Scanner sc = new Scanner(System.in);  
a = sc.nextInt();  

if((a % 2)==0) 
{  
System.out.println("even");  
}  
else
{  
System.out.println("odd");  
}
}}