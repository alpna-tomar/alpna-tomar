class GenderPercentage {
	public static void main(String arg[]) {
		int age = Integer.valueOf(arg[1]);
String s="Female";
		if (arg[0].compareTo(s)==0) {
			if (age < 58) {
				System.out.println("8.2%");
			} else
				System.out.println("9.2%");
		} else {
			if (age < 58) {
				System.out.println("8.4%");
			} else
				System.out.println("10.5%");
		}
	}
}
