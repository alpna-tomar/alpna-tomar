class even{
public static void main(String args[])
{
int i;
for(i=23;i<=57;i++)
{if(i%2==0)
System.out.println(i);
}}}