class CharAlphabetical {
	public static void main(String[] args) {
		char ch1 = 'a';
		char ch2 = 'v';
		if (Character.compare(ch1, ch2) < 0) {
			System.out.println(ch1 + "," + ch2);
		} else
			System.out.println(ch2 + "," + ch1);
	}
}