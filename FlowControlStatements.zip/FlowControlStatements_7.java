class reversecase{
public static void main(String[] args)
{
char ch='Z';
if(ch>=65 && ch<=90)
{ ch+=32;
System.out.println(ch);
}
else
{
ch-=32;
System.out.println(ch);
}
}
}