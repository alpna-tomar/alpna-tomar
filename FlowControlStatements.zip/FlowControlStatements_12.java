import java.util.Scanner;
class prime
{
public static void main(String[] arg)
{
Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();

		if (n < 2) {
			System.out.println("Not a prime");
		}

		for (int i = 2; i <= Math.sqrt(n); i++) {
			if (n % i == 0) {
				System.out.println("Not a prime number");
				return;
			}
		}

		System.out.println("Prime Number");

	}

}
