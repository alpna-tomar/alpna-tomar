class chara {
	public static void main(String[] args) {
		char ch = 0;
		if (ch>= 0 && ch<=9) {
			System.out.println("Digit");
		} else if((ch>=65&&ch<=92)||(ch>=97&&ch<=122))
			{
System.out.println("Alphabet");
	}
else
{System.out.println("Special Character");
}}}