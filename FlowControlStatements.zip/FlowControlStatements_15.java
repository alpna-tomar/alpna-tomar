class Sample
{
public static void main(String[] arg)
{
if(arg.length==0)
System.out.println("Please enter an integer number"); 
else
{int n = Integer.valueOf(arg[0]);
int i,j;
i=0;
while(i<n)
{for(j=0;j<=i;j++)
  System.out.print("* ");
System.out.print("\n");
i++;
}
}
}
}