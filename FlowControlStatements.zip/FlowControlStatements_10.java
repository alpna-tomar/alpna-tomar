class printnum
{
public static void main(String[] arg)
{int i;
for(i=1;i<=10;i++)
   {System.out.print(i);
   System.out.print("\t");
}
}
}