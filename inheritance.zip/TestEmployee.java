public class TestEmployee {

	public static void main(String[] args) {
	  Employee employee = new Employee(new Person("Wwww"), 40000.0, 2023, "aaaaa");

		System.out.println(employee.getPerson().getName() + " joined " + employee.getYearJoin() + " salary of "
				+ employee.getSalary()+" with insuranceNumber "+employee.getinsuranceNo());

	}

}