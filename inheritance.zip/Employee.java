public class Employee{
private Person person;
private double salary;
private int yearJoin;
private String insuranceNo;
public Employee(Person person,double salary,int yearJoin,String insuranceNo){
this.person=person;
this.salary= salary;
this.yearJoin=yearJoin;
this.insuranceNo=insuranceNo;
}
public Person getPerson()
{
return person;
}
public void setPerson(Person person)
{ this.person=person;
}
public double getSalary()
{
return salary;
}
public void setSalary(double salary)
{ this.salary=salary;
}
public int getYearJoin()
{
return yearJoin;
}
public void setYearJoin(int yearJoin)
{ this.yearJoin=yearJoin;
}
public String getinsuranceNo(){
return insuranceNo;
}
public void setinsuranceNo(String insuranceNo)
{
this.insuranceNo=insuranceNo;
}
}