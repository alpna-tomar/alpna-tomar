public class Orange extends Fruit {
	public void eat() {
		System.out.println("The orange tastes sweet");
	}

}