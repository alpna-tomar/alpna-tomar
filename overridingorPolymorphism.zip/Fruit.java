public class Fruit{
private String name;
private String taste;
private String color;
public void eat()
{ System.out.println("The "+ name + "taste "+taste);
}
}
