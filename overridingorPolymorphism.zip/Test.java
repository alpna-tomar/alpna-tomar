public class Test {
	public static void main(String[] args) {
		Fruit F1 =new Fruit();
		Fruit F2=new Orange();
		Fruit F=new Apple();

F1.eat();
F2.eat();
F.eat();
	}
}