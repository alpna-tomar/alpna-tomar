package thread;


public class ThreadDemo implements Runnable {
	@Override
	public void run() {
		
		System.out.println("In thread");
	}


	public static void main(String[] args) {
		Thread scooby = new Thread(new ThreadDemo());
		Thread shaggy = new Thread(new ThreadDemo());

		scooby.start();
		shaggy.start();
	}
}
