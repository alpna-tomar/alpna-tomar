class Box {
	private double height;
	private double width;
	private double depth;

	Box(double depth, double width, double height) {
		this.depth = depth;
		this.width = width;
		this.height = height;
	}

	public double volume() {
		return height * width * depth;
	}
}
class Test {

	public static void main(String[] args) {
		Box box = new Box(2, 3, 4);
		System.out.println(box.volume());
	}
	
}