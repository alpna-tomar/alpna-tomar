package music.string;
import music.playable;

public class Veena implements playable {

	@Override
	public void play() {
		// TODO Auto-generated method stub
		System.out.println("Veena is being played");
	}

}