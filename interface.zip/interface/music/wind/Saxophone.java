package music.wind;
import music.playable;

public class Saxophone implements playable {

	@Override
	public void play() {
		// TODO Auto-generated method stub
		System.out.println("Saxophone is being played");
	}

}
