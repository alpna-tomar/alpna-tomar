package live;
import music.playable;
import music.string.*;
import music.wind.*;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Veena v = new Veena();
		Saxophone s = new Saxophone();

		v.play();
		s.play();

		playable c = new Veena();
		playable d = new Saxophone();

		c.play();
		d.play();
	}

}
