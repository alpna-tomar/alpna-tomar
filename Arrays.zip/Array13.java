import java.util.Scanner;
class ReverseMatrix{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int[][] mat = new int[2][2];
		for (int i = 0; i < 2; i++) {
			for (int j = 0; j < 2; j++) {
				mat[i][j] = sc.nextInt();
			}
		}
		System.out.println("The reverse of array is:");
		for (int i = 1; i >= 0; i--) {
			for (int j = 1; j >= 0; j--) {
				System.out.print(mat[i][j] + " ");
			}			System.out.println();
         	}
	}
}