class sumandaverageArray {
   public static void main(String[] args) {
      double[] list = {1.9, 2.9, 3.4, 3.5};

      for (int i = 0; i < list.length; i++) {
         System.out.println(list[i] + " ");
      }
     
      double sum = 0;
      for (int i = 0; i < list.length; i++) {
         sum += list[i];
      }
      System.out.println("Sum is " + sum);
      double avg=0;
      avg=sum/list.length;
      System.out.println("Average is " + avg);  
   }
}