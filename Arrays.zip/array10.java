class print {
	public static void main(String[] args) {
		int[] arr = { 0,1,1,0,0,1,1 };
		int low = 0;
		int high = arr.length - 1;
		int[] ans = new int[arr.length];

		for (int i = 0; i < arr.length; i++) {
			if (arr[i] % 2 == 0) {
				ans[low++] = arr[i];
			} else
				ans[high--] = arr[i];
		}
		for (int i = 0; i < ans.length; i++) {
			System.out.print(ans[i] + " ");
		}
	}
}