class Ascii {
    public static void main(String[] args) {
	int[] arr = { 97,89, 43, 12, 67,6, 234, 7, 678};
		for (int i = 0; i < arr.length; i++) {
			char ch = (char) arr[i];
			System.out.print(ch+" ");
		}
	}
}