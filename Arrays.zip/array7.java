class Dupl {

public static void main(String[] args) {
int index=0;
int[] arr = {10,20,20,50,50,45};
int size = arr.length;
int duplicate,flag=0,count;
int[] dup= new int[size];
int i,j;
System.out.println("Array is:");
for(i=0;i<size;i++)
{
System.out.println(arr[i]);
}
for(i=0;i<size;i++)
{
count=0;
for(j=i+1;j<size;j++)
{
if(arr[i]==arr[j])
{
count=count+1;
break;
}
} 
if(count==0)
{
dup[index]=arr[i];
index++;
}
}

for(i=0;i<index;i++)
{
arr[i]=dup[i];
}
System.out.println("Removing duplicate from the array");
for(i=0;i<index;i++)
{
System.out.println(arr[i]);
}

}
}